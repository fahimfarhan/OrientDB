package com.aplications;

/**
 * Created by Fahim on 6/19/2017.
 */
public class Bounding_Box {
    String type;
    //CoordinatesArrayArray[] coordinates;

    public Bounding_Box(){}
    @Override
    public String toString(){
        /*String s = "";
        for(int i=0; i<coordinates.length;i++){
            s = s+" "+coordinates[i];
        }*/
        //return type+s;
        return type;
    }


}
