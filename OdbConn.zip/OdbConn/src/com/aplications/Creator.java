package com.aplications;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;
import com.orientechnologies.orient.core.db.document.ODatabaseDocumentTx;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Created by Fahim on 7/9/2017.
 */
public class Creator {
    Creator() throws IOException {
        //System.out.println("Hello java");
        Gson gson = new GsonBuilder().create();
        FileReader fr=null;
        BufferedReader br=null;
        JsonReader jr=null;

        AuxiliaryMethods am = new AuxiliaryMethods();

        ODatabaseDocumentTx db=null;

        try{
            String creds = "plocal:E:\\OrientDB2.2.22\\orientdb-community-2.2.22\\databases\\Aprototype1";
            db = new ODatabaseDocumentTx(creds);
            db.open("admin","admin");

            fr = new FileReader("F:\\Codes\\Java\\OrientDB\\folder\\boss.json");
            br = new BufferedReader(fr);
            jr = new JsonReader(br);
            jr.setLenient(true);

            Twitter tw = gson.fromJson(jr, Twitter.class);
            am.SetTw(tw);
            am.CreateTwitterTable();
            tw = gson.fromJson(jr, Twitter.class);
            am.SetTw(tw);
            am.CreateTablePlace();
            tw = gson.fromJson(jr, Twitter.class);
            am.SetTw(tw);
            am.CreateTableGeo();

        }catch (IOException x){System.out.println(x.fillInStackTrace());}
        catch (Exception x){System.out.println(x.fillInStackTrace());}
        finally {
            if(jr!=null){jr.close(); }//System.out.println("jr closed!");}
            if(br!=null){br.close(); }//System.out.println("br closed!");}
            if(fr!=null){fr.close(); }//System.out.println("fr closed!");}
        }
    }
}
