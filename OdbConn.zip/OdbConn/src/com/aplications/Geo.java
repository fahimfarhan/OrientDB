package com.aplications;

/**
 * Created by Fahim on 6/20/2017.
 */
public class Geo {
    String type;
    //Coordinates coordinates;
    public Geo(){}
    @Override
    public String toString(){
        //return type+coordinates;
        return type;
    }
}
